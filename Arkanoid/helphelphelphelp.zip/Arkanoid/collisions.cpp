#include "collisions.h"
#include <SDL_rect.h>
#include "engine.h"
#include "maths.h"
#include "AABB.h"
#include "player.h"
#include <iostream>

Hit intersect_pos (const AABB& a, const AABB& ball)
{
	const float dx{ ball.pos.x - a.pos.x };
	const float dy{ ball.pos.y - a.pos.y };
	int nx{ 0 }, ny{ 0 };
	float pos_x{0}, pos_y{0};

	if (intersect_x(a, ball))
	{
		std::cout << "boink x" << std::endl;
		
		ny = sign (dy);
		std::cout <<"nx: " << nx << std::endl;
		pos_x = a.pos.x + ((a.WIDTH * 0.5f) * sign (ball.pos.x - a.pos.x));
		pos_y = ball.pos.y;
	}

	else if (intersect_y(a, ball))
	{
		std::cout << "boink y" << std::endl;
		nx = sign(dx);

		std::cout << "ny: " << ny << std::endl;
		//nx = -1;
		pos_x = ball.pos.x;
		pos_y = a.pos.y + ((a.HEIGHT * 0.5f * sign (ball.pos.y - a.pos.y)));
	}

	return { (float)nx, (float)ny, ball.pos.x, a.pos.y };
}

Hit intersect_player (const AABB& a, const AABB& ball, float velocity_x)
{
	float x{ 1 }, y{ 1 }, pos_x{ 0 }, pos_y{ 0 };

	if (intersect_x (a, ball))
	{
		const float MID = a.WIDTH / 2;
		const float VEL_Y = (a.WIDTH / a.WIDTH) * 10 / (ball.pos.x - a.pos.x);
		const float DIFF_X = a.X_MAX - a.X_MIN;
		y = -1;

		const float NEAREST_POINT_X{ clamp (ball.pos.x, a.X_MIN, a.X_MAX) };

		if (NEAREST_POINT_X < (a.X_MIN + DIFF_X * 0.1f))
		{
			velocity_x < 0 ? x = 1 : x = -1;
		}

		else if (NEAREST_POINT_X > (a.X_MAX - DIFF_X * 0.1f))
		{
			velocity_x > 0 ? x = 1 : x = -1;
		}

		else
		{
			x = 1;
		}

		pos_x = a.pos.x + ((a.WIDTH * 0.5f) * sign (ball.pos.x - a.pos.x));
		pos_y = ball.pos.y;
	}

	else if (intersect_y (a, ball))
	{
		x = -1;
		pos_x = ball.pos.x;
		pos_y = a.pos.y + ((a.HEIGHT * 0.5f * sign (ball.pos.y - a.pos.y)));
	}

	return { x, y, ball.pos.x, a.pos.y };
}

bool aabb_intersect (const AABB& a, const AABB& ball)
{
	const float RAD = ball.WIDTH * 0.5f;

	const tove::Vector2 CLOSEST_POINT = get_closest_point (a, ball.pos);

	const tove::Vector2 DIFF{ (CLOSEST_POINT.x - ball.pos.x), (CLOSEST_POINT.y - ball.pos.y) };

	const float DIST_SQRD = dot((DIFF), (DIFF));
	const float RAD_SQRD = ball.WIDTH * ball.WIDTH;

	return RAD_SQRD > DIST_SQRD;
}

bool intersect_x (const AABB& a, const AABB& ball)
{
	const float RAD = ball.WIDTH * 0.5f;

	const float CLOSEST_POINT{ clamp (ball.pos.x, a.X_MIN, a.X_MAX) };

	const float DIFF{ CLOSEST_POINT - ball.pos.x };

	const float DIST_SQRD = DIFF * DIFF;
	const float RAD_SQRD = RAD * RAD;

	return RAD_SQRD > DIST_SQRD;
}

bool intersect_y(const AABB& a, const AABB& ball)
{
	const float RAD = ball.WIDTH * 0.5f;

	const float CLOSEST_POINT{ clamp (ball.pos.y, a.Y_MIN, a.Y_MAX) };

	const float DIFF{ CLOSEST_POINT - ball.pos.y };

	const float DIST_SQRD = DIFF * DIFF;
	const float RAD_SQRD = RAD * RAD;

	return RAD_SQRD > DIST_SQRD;
}

tove::Vector2 get_closest_point(const AABB AABB, const tove::Vector2 POINT)
{
	return { clamp (POINT.x, AABB.X_MIN, AABB.X_MAX),
			clamp(POINT.y, AABB.Y_MIN, AABB.Y_MAX) };
}
